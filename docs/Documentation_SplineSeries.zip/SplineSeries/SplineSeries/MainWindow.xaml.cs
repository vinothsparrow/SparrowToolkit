﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SplineSeries
{   
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();
        }
    }

    public class Model
    {
        public double X { get; set; }
        public double Y { get; set; }

        public Model(double x,double y)
        {
            X = x;
            Y = y;
        }
    }

    public class ViewModel
    {
        public ObservableCollection<Model> Collection { get; set; }

        public ViewModel()
        {
            Collection = new ObservableCollection<Model>();
            Collection.Add(new Model(0, 1));
            Collection.Add(new Model(1, 2));
            Collection.Add(new Model(2, 3));
            Collection.Add(new Model(3, 2));
            Collection.Add(new Model(4, 1));
        }
    }
}
